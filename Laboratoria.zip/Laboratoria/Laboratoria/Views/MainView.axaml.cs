using System.Linq;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Laboratoria.Classes;
using Microsoft.EntityFrameworkCore;
using MsBox.Avalonia;
using MsBox.Avalonia.Dto;

namespace Laboratoria.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }

    private void VhodBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.LC.Users.Where(el => el.Deleted == 1).Load();
        var user = Help.LC.Users.FirstOrDefault(el => el.Login == LoginTB.Text && el.Pasword == PwdTB.Text);
        if (user == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Ошибка", "Неверный логин или пароль").ShowAsync();
            return;
        }

        Help.Str = user.LastName + " " + user.Name;
        
        if (user.Role == "admin")
        {
            Help.CC.Content = new Admin();
        }
        
        if (user.Role == "buxgalter")
        {
            Help.CC.Content = new Byxgalter();
        }
        
        if (user.Role == "laborant")
        {
            Help.CC.Content = new Laborant();
        }
        
        if (user.Role == "laborant_researcher")
        {
            Help.CC.Content = new Laborant_researcher();
        }
    }
}
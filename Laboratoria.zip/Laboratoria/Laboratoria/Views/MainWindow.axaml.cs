using Avalonia.Controls;
using Avalonia.Interactivity;
using Laboratoria.Classes;

namespace Laboratoria.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        Help.CC = this;
        Help.CC = CCW;
        CCW.Content = new MainView();
    }

    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.CC.Content = new MainView();
    }
}
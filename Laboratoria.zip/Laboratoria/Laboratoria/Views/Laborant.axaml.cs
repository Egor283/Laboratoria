using Avalonia.Controls;
using Avalonia.Interactivity;
using Laboratoria.Classes;

namespace Laboratoria.Views;

public partial class Laborant : UserControl
{
    public Laborant()
    {
        InitializeComponent();
        Label.Content = Help.Str;
    }
}
using Avalonia.Controls;
using Avalonia.Interactivity;
using Laboratoria.Classes;

namespace Laboratoria.Views;

public partial class Laborant_researcher: UserControl
{
    public Laborant_researcher()
    {
        InitializeComponent();
        Labelr.Content = Help.Str;
    }
}
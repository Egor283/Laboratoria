using Avalonia.Controls;
using Avalonia.Interactivity;
using Laboratoria.Classes;

namespace Laboratoria.Views;

public partial class Admin : UserControl
{
    public Admin()
    {
        InitializeComponent();
        Lab.Content = Help.Str;
    }

    private void UserBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.CC.Content = new TableUsers();
    }
}
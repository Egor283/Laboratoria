using Avalonia.Controls;
using Avalonia.Interactivity;
using Laboratoria.Classes;

namespace Laboratoria.Views;

public partial class Byxgalter : UserControl
{
    public Byxgalter()
    {
        InitializeComponent();
        Labe.Content = Help.Str;
    }
}
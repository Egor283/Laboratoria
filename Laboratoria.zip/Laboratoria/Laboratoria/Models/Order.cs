﻿using System;
using System.Collections.Generic;

namespace Laboratoria.Models;

public partial class Order
{
    public int Id { get; set; }

    public string DateCreation { get; set; } = null!;

    public string Uslugi { get; set; } = null!;

    public string StatusOrder { get; set; } = null!;

    public string StatusUslugi { get; set; } = null!;

    public string DateCompletion { get; set; } = null!;
}

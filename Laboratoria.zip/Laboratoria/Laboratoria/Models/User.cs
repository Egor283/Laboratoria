﻿using System;
using System.Collections.Generic;

namespace Laboratoria.Models;

public partial class User
{
    public int Id { get; set; }

    public string Login { get; set; } = null!;

    public string Pasword { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string Otchestvo { get; set; } = null!;

    public string? Bithday { get; set; }

    public string? SeriaPassport { get; set; }

    public string? NumberPassport { get; set; }

    public string? Phone { get; set; }

    public string? EMai { get; set; }

    public string? NumberSP { get; set; }

    public string? TipSP { get; set; }

    public string? StraxovaiCompany { get; set; }

    public string? DateLastLogin { get; set; }

    public string? Uslugi { get; set; }

    public string? ScoreSP { get; set; }

    public string Role { get; set; } = null!;

    public int Deleted { get; set; }
}

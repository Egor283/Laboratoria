﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Scaffolding.Internal;

namespace Laboratoria.Models;

public partial class LaboratoriaContext : DbContext
{
    public LaboratoriaContext()
    {
    }

    public LaboratoriaContext(DbContextOptions<LaboratoriaContext> options)
        : base(options)
    {
    }

    public virtual DbSet<DataAnalizator> DataAnalizators { get; set; }

    public virtual DbSet<DataSP> DataSPs { get; set; }

    public virtual DbSet<Order> Orders { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<Uslugi> Uslugis { get; set; }

    public virtual DbSet<VblpolnenbleUslugi> VblpolnenbleUslugis { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=127.0.0.1;database=laboratoria;uid=root;pwd=1234", Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.41-mysql"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_0900_ai_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<DataAnalizator>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("data analizator");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.DatePostuplenia)
                .HasMaxLength(45)
                .HasColumnName("date postuplenia");
            entity.Property(e => e.DateVblpolnenia)
                .HasMaxLength(45)
                .HasColumnName("date vblpolnenia");
        });

        modelBuilder.Entity<DataSP>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("data s.p.");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Adress)
                .HasMaxLength(45)
                .HasColumnName("adress");
            entity.Property(e => e.BIK)
                .HasMaxLength(45)
                .HasColumnName("b.i.k.");
            entity.Property(e => e.INN)
                .HasMaxLength(45)
                .HasColumnName("i.n.n.");
            entity.Property(e => e.Name)
                .HasMaxLength(45)
                .HasColumnName("name");
            entity.Property(e => e.RS)
                .HasMaxLength(45)
                .HasColumnName("r/s");
        });

        modelBuilder.Entity<Order>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("order");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.DateCompletion)
                .HasMaxLength(45)
                .HasColumnName("date completion");
            entity.Property(e => e.DateCreation)
                .HasMaxLength(45)
                .HasColumnName("date creation");
            entity.Property(e => e.StatusOrder)
                .HasMaxLength(45)
                .HasColumnName("status order");
            entity.Property(e => e.StatusUslugi)
                .HasMaxLength(45)
                .HasColumnName("status uslugi");
            entity.Property(e => e.Uslugi)
                .HasMaxLength(45)
                .HasColumnName("uslugi");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("user");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Bithday)
                .HasMaxLength(45)
                .HasColumnName("bithday");
            entity.Property(e => e.DateLastLogin)
                .HasMaxLength(45)
                .HasColumnName("date last login");
            entity.Property(e => e.Deleted)
                .HasDefaultValueSql("'1'")
                .HasColumnName("deleted");
            entity.Property(e => e.EMai)
                .HasMaxLength(45)
                .HasColumnName("e-mai");
            entity.Property(e => e.LastName)
                .HasMaxLength(45)
                .HasColumnName("last name");
            entity.Property(e => e.Login)
                .HasMaxLength(45)
                .HasColumnName("login");
            entity.Property(e => e.Name)
                .HasMaxLength(45)
                .HasColumnName("name");
            entity.Property(e => e.NumberPassport)
                .HasMaxLength(45)
                .HasColumnName("number passport");
            entity.Property(e => e.NumberSP)
                .HasMaxLength(45)
                .HasColumnName("number S.P.");
            entity.Property(e => e.Otchestvo)
                .HasMaxLength(45)
                .HasColumnName("otchestvo");
            entity.Property(e => e.Pasword)
                .HasMaxLength(45)
                .HasColumnName("pasword");
            entity.Property(e => e.Phone)
                .HasMaxLength(45)
                .HasColumnName("phone");
            entity.Property(e => e.Role)
                .HasMaxLength(45)
                .HasColumnName("role");
            entity.Property(e => e.ScoreSP)
                .HasMaxLength(45)
                .HasColumnName("score S.P");
            entity.Property(e => e.SeriaPassport)
                .HasMaxLength(45)
                .HasColumnName("seria passport");
            entity.Property(e => e.StraxovaiCompany)
                .HasMaxLength(45)
                .HasColumnName("Straxovai company");
            entity.Property(e => e.TipSP)
                .HasMaxLength(45)
                .HasColumnName("tip S.P.");
            entity.Property(e => e.Uslugi)
                .HasMaxLength(45)
                .HasColumnName("uslugi");
        });

        modelBuilder.Entity<Uslugi>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("uslugi");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CodYclygi)
                .HasMaxLength(45)
                .HasColumnName("cod yclygi");
            entity.Property(e => e.CredneeOtklonenie)
                .HasMaxLength(45)
                .HasColumnName("crednee otklonenie");
            entity.Property(e => e.Naiminovanie)
                .HasMaxLength(45)
                .HasColumnName("naiminovanie");
            entity.Property(e => e.SrokVipolnenia)
                .HasMaxLength(45)
                .HasColumnName("srok vipolnenia");
            entity.Property(e => e.Stoimost)
                .HasMaxLength(45)
                .HasColumnName("stoimost");
        });

        modelBuilder.Entity<VblpolnenbleUslugi>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("vblpolnenble uslugi");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.KakoiAnalizator)
                .HasMaxLength(45)
                .HasColumnName("kakoi analizator");
            entity.Property(e => e.KogdaBbllaVblpolnena)
                .HasMaxLength(45)
                .HasColumnName("kogda bblla vblpolnena");
            entity.Property(e => e.KtoVblpolnil)
                .HasMaxLength(45)
                .HasColumnName("kto vblpolnil");
            entity.Property(e => e.Uslugi)
                .HasMaxLength(45)
                .HasColumnName("uslugi");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

﻿using System;
using System.Collections.Generic;

namespace Laboratoria.Models;

public partial class VblpolnenbleUslugi
{
    public int Id { get; set; }

    public string Uslugi { get; set; } = null!;

    public string KtoVblpolnil { get; set; } = null!;

    public string KogdaBbllaVblpolnena { get; set; } = null!;

    public string KakoiAnalizator { get; set; } = null!;
}

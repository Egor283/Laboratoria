﻿using System;
using System.Collections.Generic;

namespace Laboratoria.Models;

public partial class DataAnalizator
{
    public int Id { get; set; }

    public string DatePostuplenia { get; set; } = null!;

    public string DateVblpolnenia { get; set; } = null!;
}

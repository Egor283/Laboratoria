﻿using System;
using System.Collections.Generic;

namespace Laboratoria.Models;

public partial class DataSP
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string Adress { get; set; } = null!;

    public string INN { get; set; } = null!;

    public string RS { get; set; } = null!;

    public string BIK { get; set; } = null!;
}

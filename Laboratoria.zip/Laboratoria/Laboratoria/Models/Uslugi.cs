﻿using System;
using System.Collections.Generic;

namespace Laboratoria.Models;

public partial class Uslugi
{
    public int Id { get; set; }

    public string Naiminovanie { get; set; } = null!;

    public string Stoimost { get; set; } = null!;

    public string CodYclygi { get; set; } = null!;

    public string SrokVipolnenia { get; set; } = null!;

    public string CredneeOtklonenie { get; set; } = null!;
}

﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Laboratoria.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}
﻿using System;
using Avalonia.Controls;
using Laboratoria.Models;
using Laboratoria.Views;
using Laboratoria.WindowAdds;

namespace Laboratoria.Classes;

public static class Help
{
    public static ContentControl CC = null;
    public static LaboratoriaContext LC = new LaboratoriaContext();
    public static String Str;
    public static MainWindow Mainwindow { get; set; }
    public static Window Adduserwindow { get; set; }
}
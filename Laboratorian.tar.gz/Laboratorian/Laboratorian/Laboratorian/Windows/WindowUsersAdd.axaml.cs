using System.Linq;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Laboratorian.Classes;
using Laboratorian.Models;
using Laboratorian.Views;
using Microsoft.EntityFrameworkCore;

namespace Laboratorian.Windows;

public partial class WindowUsersAdd : Window
{
    private int _id;
    public WindowUsersAdd(int id = -1)
    {
        InitializeComponent();
        Help.Test.Users.Load();
        _id = id;
        if (_id == -1)
        {
            StPn.DataContext = new User();    
        }
        else
        {
            var user = Help.Test.Users.FirstOrDefault(el => el.Id == _id);
            StPn.DataContext = user;
        }
    }

    private void OKBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        if (_id == -1)
        {
            Help.Test.Users.Add(StPn.DataContext as User);
        }
        Help.Test.SaveChanges();
        Help.HCC.Content = new Users();
        Close();
    }
}
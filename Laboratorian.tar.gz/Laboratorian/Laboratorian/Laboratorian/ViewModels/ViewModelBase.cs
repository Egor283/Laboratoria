﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Laboratorian.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}
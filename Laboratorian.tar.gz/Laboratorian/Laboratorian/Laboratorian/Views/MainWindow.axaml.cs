using Avalonia.Controls;
using Avalonia.Interactivity;
using Laboratorian.Classes;

namespace Laboratorian.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        Help.HCC = this;
        Help.HCC = CCV;
        CCV.Content = new MainView();
    }

    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.HCC.Content = new MainView();
    }
}
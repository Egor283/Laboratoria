using System.Linq;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Laboratorian.Classes;
using Laboratorian.Models;
using Laboratorian.Windows;
using Microsoft.EntityFrameworkCore;
using MsBox.Avalonia;

namespace Laboratorian.Views;

public partial class Users : UserControl
{
    public Users()
    {
        InitializeComponent();
        LoadData(1);
    }

    private void LoadData(int t)
    {
        Help.Test.Users.Load();
        DG.ItemsSource = Help.Test.Users.Where(el => el.Deleted == t).ToList();
    }

    private void DelBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        var us = DG.SelectedItem as User;
        if (us == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Ошибка", "Вы не выбрали пользователя").ShowAsync();
            return;
        }

        us.Deleted = 0;
        Help.Test.Users.Update(us);
        Help.Test.SaveChanges();
        DG.ItemsSource = null;
        LoadData(1);
    }
    
    private void ArxivBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        LoadData(0);
    }

    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        LoadData(1);
    }

    private void DobBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        Window win = new WindowUsersAdd();
        win.Show();
    }

    private void EditBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        var usr = DG.SelectedItem as User;
        if (usr == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Ошибка", "Вы не выбрали пользователя").ShowAsync();
            return;
        }
        Window win = new WindowUsersAdd(usr.Id);
        win.Show();
    }

    private void VosBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        var us = DG.SelectedItem as User;
        if (us == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Ошибка", "Вы не выбрали пользователя").ShowAsync();
            return;
        }

        us.Deleted = 1;
        Help.Test.Users.Update(us);
        Help.Test.SaveChanges();
        DG.ItemsSource = null;
        LoadData(0);
    }
}
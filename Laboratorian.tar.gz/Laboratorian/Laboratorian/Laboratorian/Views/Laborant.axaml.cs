using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using Laboratorian.Classes;

namespace Laboratorian.Views;

public partial class Laborant : UserControl
{
    public Laborant()
    {
        InitializeComponent();
        FiLab.Content = Help.str;
    }
}
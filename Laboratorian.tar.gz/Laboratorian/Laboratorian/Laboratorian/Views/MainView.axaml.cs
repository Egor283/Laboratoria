using System.Linq;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Laboratorian.Classes;
using Microsoft.EntityFrameworkCore;
using MsBox.Avalonia;

namespace Laboratorian.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
        Help.Test.Users.Load();
    }

    private void AvtoBtn_OnClick(object? sender, RoutedEventArgs e)
    {
        var us = Help.Test.Users.Where(el => el.Login == LoginTB.Text && el.Password == PasTB.Text).FirstOrDefault();
        if (us == null)
        {
            MessageBoxManager.GetMessageBoxStandard("Ошибка", "Неверный логин или пароль").ShowAsync();
            return;
        }
        Help.str = us.Firstname + " " + us.Name;

        if (us.Role == "admin")
        {
            Help.HCC.Content = new Admin();
        }
        
        if (us.Role == "laborant")
        {
            Help.HCC.Content = new Laborant();
        }
        
        if (us.Role == "laborant_1")
        {
            Help.HCC.Content = new Laborant_1View();
        }
        
        if (us.Role == "buxgalter")
        {
            
        }
    }
}
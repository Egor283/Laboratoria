using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using Laboratorian.Classes;
using Laboratorian.Models;

namespace Laboratorian.Views;

public partial class Admin : UserControl
{
    public Admin()
    {
        InitializeComponent();
        FIOLab.Content = Help.str;
    }

    private void Button_OnClick(object? sender, RoutedEventArgs e)
    {
        Help.HCC.Content = new Users();
    }
}
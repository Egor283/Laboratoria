using System;
using Avalonia.Controls;
using Laboratorian.Models;

namespace Laboratorian.Classes;

public static class Help
{
    public static ContentControl HCC = new ContentControl();
    public static TestContext Test  = new TestContext();
    public static String str;
    public static Window Win;
}